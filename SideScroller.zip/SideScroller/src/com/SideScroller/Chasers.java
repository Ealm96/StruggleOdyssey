package com.SideScroller;

public class Chasers extends EnemyCruiser {

	public Chasers(int x, int y, String file, String[] action, int count, int duration, int w, int h) {
		super(x, y, file, action, count, duration, w, h);

	}

	public void chase(SpaceCruiser sc, Bullet b) {

		this.x -= 10;

		if (hit(sc) && sc.dmgTaken == false) {
			destroyed = true;
			sc.dmgTaken = true;
			sc.hp -= 1;
			this.x = 1500;
			sc.invFrame();
			System.out.println("Damage Taken\n" + "HP = " + sc.hp);
		}
		
		if(this.x < sc.x + 300) {
			if(this.y < sc.y)
				this.y += 3;
			if(this.y > sc.y)
				this.y -= 3;
		}

		if (this.x < -20) {
			this.x = 1500;
		}

		if (this.x == 1500) {
			destroyed = false;
			collide = false;
			hitBB = false;
			inRange = false;
			this.y = RandomY();
		}
	}

}
