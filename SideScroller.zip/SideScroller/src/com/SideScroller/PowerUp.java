package com.SideScroller;

public class PowerUp {

}
